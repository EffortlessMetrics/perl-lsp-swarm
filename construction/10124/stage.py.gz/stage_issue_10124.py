#!/usr/bin/env python3
"""Build and publish the focused issue #10124 static-contract candidate.

This helper exists only on a disposable construction branch. It patches one
exact main subject, proves the focused contract, and publishes a clean commit
containing only the five production files owned by the issue.
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import subprocess
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

BASE_SHA = "cdc3bdce56bdda4b5d3fcc4e7d4d2cbbec19a266"
TARGET_BRANCH = "codex/10124-static-app-bindings"
PRODUCTION_PATHS = (
    ".ci/policies/required-checks.toml",
    ".github/workflows/gate-enforcement-contract.yml",
    "docs/ci/gate-enforcement-app-bindings.md",
    "scripts/ci/test_gate_enforcement_app_bindings.py",
    "scripts/ci/validate_gate_enforcement_contract.py",
)

TEST_SOURCE = r'''#!/usr/bin/env python3
"""Focused falsifiers for source-specific GitHub enforcement bindings."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
import unittest
from pathlib import Path
from typing import Any

SCRIPT = Path(__file__).with_name("validate_gate_enforcement_contract.py")
SPEC = importlib.util.spec_from_file_location("gate_enforcement_contract_bindings", SCRIPT)
assert SPEC and SPEC.loader
contract = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = contract
SPEC.loader.exec_module(contract)


def required_entry(enforcement: str, **overrides: Any) -> dict[str, Any]:
    entry: dict[str, Any] = {
        "name": "Bound Check",
        "producer": "external",
        "workflow": "github-app",
        "required": True,
        "policy_role": "required",
        "applicability": "always-or-scoped-noop",
        "enforcement": enforcement,
    }
    entry.update(overrides)
    return entry


def finding_codes(entry: dict[str, Any]) -> set[str]:
    findings, _ = contract.validate_context(entry, {}, {})
    return {finding.code for finding in findings}


def canonical_digest(entry: dict[str, Any]) -> str:
    payload = json.dumps(
        contract._canonical_context(entry),
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


class AppBindingContractTests(unittest.TestCase):
    def test_valid_source_specific_bindings_are_accepted(self) -> None:
        cases = (
            required_entry(
                "github-branch-protection",
                classic_app_id=15368,
            ),
            required_entry(
                "github-ruleset",
                ruleset_integration_id=15368,
            ),
            required_entry(
                "github-branch-protection+ruleset",
                classic_app_id=15368,
                ruleset_integration_id=15368,
            ),
        )
        for entry in cases:
            with self.subTest(entry=entry):
                self.assertEqual(set(), finding_codes(entry))

    def test_canonical_subject_retains_explicit_bindings(self) -> None:
        canonical = contract._canonical_context(
            required_entry(
                "github-branch-protection+ruleset",
                classic_app_id=15368,
                ruleset_integration_id=4242,
            )
        )
        self.assertEqual(15368, canonical["classic_app_id"])
        self.assertEqual(4242, canonical["ruleset_integration_id"])

    def test_absent_bindings_are_not_synthesized_from_producer(self) -> None:
        entry = required_entry("github-ruleset", producer="repository-job")
        canonical = contract._canonical_context(entry)
        self.assertNotIn("classic_app_id", canonical)
        self.assertNotIn("ruleset_integration_id", canonical)

    def test_invalid_binding_values_fail_closed(self) -> None:
        for field in ("classic_app_id", "ruleset_integration_id"):
            enforcement = (
                "github-branch-protection"
                if field == "classic_app_id"
                else "github-ruleset"
            )
            for value in (0, -1, "15368", True):
                with self.subTest(field=field, value=value):
                    entry = required_entry(enforcement, **{field: value})
                    self.assertIn(f"invalid_{field}", finding_codes(entry))

    def test_classic_binding_requires_classic_enforcement(self) -> None:
        entry = required_entry("github-ruleset", classic_app_id=15368)
        self.assertIn(
            "classic_app_id_source_mismatch",
            finding_codes(entry),
        )

    def test_ruleset_binding_requires_ruleset_enforcement(self) -> None:
        entry = required_entry(
            "github-branch-protection",
            ruleset_integration_id=15368,
        )
        self.assertIn(
            "ruleset_integration_id_source_mismatch",
            finding_codes(entry),
        )

    def test_binding_change_changes_static_subject_identity(self) -> None:
        first = required_entry(
            "github-branch-protection",
            classic_app_id=15368,
        )
        second = required_entry(
            "github-branch-protection",
            classic_app_id=4242,
        )
        self.assertNotEqual(canonical_digest(first), canonical_digest(second))


if __name__ == "__main__":
    unittest.main()
'''

DOC_SOURCE = r'''# Gate enforcement app bindings

The Gate Enforcement Contract keeps three identities separate:

1. **Producer identity** names the workflow job or external integration that emits a status context.
2. **Classic app identity** names the GitHub App to which classic branch protection binds that context.
3. **Ruleset integration identity** names the integration to which a ruleset binds that context.

These facts may coincide, but none is inferred from another. A repository-owned job does not, by itself, prove that classic protection or a ruleset requires the context from GitHub Actions.

## Static policy fields

A `[[checks]]` row may declare either source-specific binding:

```toml
classic_app_id = 15368
ruleset_integration_id = 15368
```

`classic_app_id` is valid only when `enforcement` includes `github-branch-protection`. `ruleset_integration_id` is valid only when `enforcement` includes `github-ruleset`. Each present value must be a positive integer; booleans, strings, zero, and negative values fail the static contract.

Absence is meaningful. It means the checked-in policy does not require or prove an app binding for that enforcement source. The validator does not synthesize an identity from `producer`, workflow path, job id, or context name.

## Current checked-in state

Classic protection currently declares explicit GitHub Actions app bindings for:

```text
Perl LSP Rust Small Result  classic_app_id = 15368
ripr+ New Gap Gate          classic_app_id = 15368
```

The current ruleset-required contexts remain intentionally unbound in static policy because the live ruleset does not declare an integration id:

```text
Compile All Targets (bit-rot guard)
Conflict marker check
validate-title
```

That distinction prevents the live-union reconciler from turning a repository-job producer into a fabricated ruleset integration requirement.

## Receipt behavior

Both optional fields are retained in `subjects.contexts` and therefore participate in the schema-v2 `subject_sha256`. Changing a declared binding changes the exact static subject consumed by downstream reconciliation.

This contract remains static and read-only. It does not query GitHub, collect live rulesets or branch protection, evaluate check conclusions, mutate repository settings, or authorize promotion. Issue #9152 consumes the explicit binding fields; issue #9154 owns trusted live observation.
'''


def fail(message: str) -> None:
    raise SystemExit(message)


def replace_once(path: Path, old: str, new: str, label: str) -> None:
    text = path.read_text(encoding="utf-8")
    count = text.count(old)
    if count != 1:
        fail(f"{label}: expected exactly one match in {path}, found {count}")
    path.write_text(text.replace(old, new, 1), encoding="utf-8")


def patch() -> None:
    validator = Path("scripts/ci/validate_gate_enforcement_contract.py")
    replace_once(
        validator,
        '''REQUIRED_ENFORCEMENT = {
    "github-branch-protection",
    "github-ruleset",
    "github-branch-protection+ruleset",
}
NON_REQUIRED_ENFORCEMENT = {"neither", "local", "not-proven"}
''',
        '''REQUIRED_ENFORCEMENT = {
    "github-branch-protection",
    "github-ruleset",
    "github-branch-protection+ruleset",
}
CLASSIC_ENFORCEMENT = {
    "github-branch-protection",
    "github-branch-protection+ruleset",
}
RULESET_ENFORCEMENT = {
    "github-ruleset",
    "github-branch-protection+ruleset",
}
NON_REQUIRED_ENFORCEMENT = {"neither", "local", "not-proven"}
''',
        "enforcement source sets",
    )

    replace_once(
        validator,
        '''def validate_context(
    entry: dict[str, Any],
    workflows: dict[str, Workflow],
    producers: dict[str, list[tuple[str, str]]],
) -> tuple[list[Finding], bool]:
''',
        '''def _binding_findings(
    entry: dict[str, Any],
    *,
    field: str,
    allowed_enforcement: set[str],
    subject: str,
) -> list[Finding]:
    if field not in entry:
        return []
    value = entry[field]
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        return [
            Finding(
                f"invalid_{field}",
                subject,
                f"{field} must be a positive integer",
            )
        ]
    if entry.get("enforcement") not in allowed_enforcement:
        return [
            Finding(
                f"{field}_source_mismatch",
                subject,
                f"{field} is incompatible with enforcement {entry.get('enforcement')!r}",
            )
        ]
    return []


def validate_context(
    entry: dict[str, Any],
    workflows: dict[str, Workflow],
    producers: dict[str, list[tuple[str, str]]],
) -> tuple[list[Finding], bool]:
''',
        "binding validation helper",
    )

    replace_once(
        validator,
        '''    if role in {"advisory", "informational", "local"} and enforcement not in NON_REQUIRED_ENFORCEMENT:
        findings.append(Finding("nonrequired_claims_github_enforcement", name, f"non-required role claims {enforcement!r}"))

    workflow = entry.get("workflow")
''',
        '''    if role in {"advisory", "informational", "local"} and enforcement not in NON_REQUIRED_ENFORCEMENT:
        findings.append(Finding("nonrequired_claims_github_enforcement", name, f"non-required role claims {enforcement!r}"))

    findings.extend(
        _binding_findings(
            entry,
            field="classic_app_id",
            allowed_enforcement=CLASSIC_ENFORCEMENT,
            subject=name,
        )
    )
    findings.extend(
        _binding_findings(
            entry,
            field="ruleset_integration_id",
            allowed_enforcement=RULESET_ENFORCEMENT,
            subject=name,
        )
    )

    workflow = entry.get("workflow")
''',
        "context binding findings",
    )

    replace_once(
        validator,
        '''        "applicability",
        "enforcement",
        "events",
''',
        '''        "applicability",
        "enforcement",
        "classic_app_id",
        "ruleset_integration_id",
        "events",
''',
        "canonical binding fields",
    )

    policy = Path(".ci/policies/required-checks.toml")
    replace_once(
        policy,
        '''# - applicability: always, conditional, planned, or not applicable
# - enforcement: claimed classic-protection/ruleset source
''',
        '''# - applicability: always, conditional, planned, or not applicable
# - enforcement: claimed classic-protection/ruleset source
# - classic_app_id: explicit classic-protection GitHub App binding
# - ruleset_integration_id: explicit ruleset integration binding
#
# Producer and enforcement binding are separate axes. Neither binding is
# inferred from the workflow, job, producer class, or context name.
''',
        "policy binding documentation",
    )

    replace_once(
        policy,
        '''name = "Perl LSP Rust Small Result"
producer = "repository-job"
workflow = ".github/workflows/em-ci-routed-rust.yml"
job = "rust-small-result"
workflow_result = "propagate"
events = ["pull_request", "merge_group"]
required = true
policy_role = "required"
applicability = "always-or-scoped-noop"
enforcement = "github-branch-protection"
reason = "Live main protection requires the routed Rust aggregate before merge."
''',
        '''name = "Perl LSP Rust Small Result"
producer = "repository-job"
workflow = ".github/workflows/em-ci-routed-rust.yml"
job = "rust-small-result"
workflow_result = "propagate"
events = ["pull_request", "merge_group"]
required = true
policy_role = "required"
applicability = "always-or-scoped-noop"
enforcement = "github-branch-protection"
classic_app_id = 15368
reason = "Live main protection requires the routed Rust aggregate before merge."
''',
        "routed Rust classic binding",
    )

    replace_once(
        policy,
        '''name = "ripr+ New Gap Gate"
producer = "repository-job"
workflow = ".github/workflows/ripr.yml"
job = "ripr"
workflow_result = "propagate"
events = ["pull_request", "merge_group"]
required = true
policy_role = "required"
applicability = "always-or-scoped-noop"
enforcement = "github-branch-protection"
reason = "Deterministic RIPR receipts are required; named new gaps in changed production files block, while sensor availability remains advisory."
''',
        '''name = "ripr+ New Gap Gate"
producer = "repository-job"
workflow = ".github/workflows/ripr.yml"
job = "ripr"
workflow_result = "propagate"
events = ["pull_request", "merge_group"]
required = true
policy_role = "required"
applicability = "always-or-scoped-noop"
enforcement = "github-branch-protection"
classic_app_id = 15368
reason = "Deterministic RIPR receipts are required; named new gaps in changed production files block, while sensor availability remains advisory."
''',
        "ripr classic binding",
    )

    workflow = Path(".github/workflows/gate-enforcement-contract.yml")
    replace_once(
        workflow,
        '''          python3 -m unittest scripts/ci/test_validate_gate_enforcement_contract.py
          test_status=$?
''',
        '''          python3 -m unittest \\
            scripts/ci/test_validate_gate_enforcement_contract.py \\
            scripts/ci/test_gate_enforcement_app_bindings.py
          test_status=$?
''',
        "workflow focused falsifier list",
    )

    Path("scripts/ci/test_gate_enforcement_app_bindings.py").write_text(
        TEST_SOURCE,
        encoding="utf-8",
    )
    Path("docs/ci/gate-enforcement-app-bindings.md").write_text(
        DOC_SOURCE,
        encoding="utf-8",
    )

    status = subprocess.check_output(
        ["git", "status", "--porcelain"], text=True
    ).splitlines()
    changed = {line[3:] for line in status if line}
    expected = set(PRODUCTION_PATHS)
    if changed != expected:
        fail(
            "production path set drifted: "
            f"missing={sorted(expected - changed)} extra={sorted(changed - expected)}"
        )


def run(command: list[str]) -> None:
    print("+", " ".join(command), flush=True)
    subprocess.run(command, check=True)


def verify() -> None:
    run(["git", "diff", "--check"])
    run(
        [
            "python3",
            "-m",
            "py_compile",
            "scripts/ci/validate_gate_enforcement_contract.py",
            "scripts/ci/test_validate_gate_enforcement_contract.py",
            "scripts/ci/test_gate_enforcement_app_bindings.py",
        ]
    )
    run(
        [
            "python3",
            "-m",
            "unittest",
            "-v",
            "scripts/ci/test_validate_gate_enforcement_contract.py",
            "scripts/ci/test_gate_enforcement_app_bindings.py",
        ]
    )


def request(method: str, path: str, payload: object | None = None) -> object:
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        f"https://api.github.com/repos/{os.environ['GITHUB_REPOSITORY']}{path}",
        data=data,
        method=method,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {os.environ['GITHUB_TOKEN']}",
            "Content-Type": "application/json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as response:
            return json.load(response)
    except urllib.error.HTTPError as error:
        fail(
            f"GitHub API {method} {path} failed: {error.code} "
            f"{error.read().decode(errors='replace')}"
        )


def require_object(value: object, label: str) -> dict[str, object]:
    if not isinstance(value, dict):
        fail(f"{label} response must be an object")
    return value


def require_sha(value: object, label: str) -> str:
    if not isinstance(value, str) or len(value) != 40:
        fail(f"{label} must be a 40-character SHA")
    return value


def publish() -> None:
    base_commit = require_object(
        request("GET", f"/git/commits/{BASE_SHA}"), "base commit"
    )
    base_tree = require_object(base_commit.get("tree"), "base commit tree")
    base_tree_sha = require_sha(base_tree.get("sha"), "base commit tree.sha")

    entries = []
    for raw_path in PRODUCTION_PATHS:
        data = Path(raw_path).read_bytes()
        blob = require_object(
            request(
                "POST",
                "/git/blobs",
                {
                    "content": base64.b64encode(data).decode("ascii"),
                    "encoding": "base64",
                },
            ),
            f"blob {raw_path}",
        )
        entries.append(
            {
                "path": raw_path,
                "mode": "100755" if raw_path.startswith("scripts/ci/") else "100644",
                "type": "blob",
                "sha": require_sha(blob.get("sha"), f"blob {raw_path}.sha"),
            }
        )

    tree = require_object(
        request(
            "POST",
            "/git/trees",
            {"base_tree": base_tree_sha, "tree": entries},
        ),
        "candidate tree",
    )
    tree_sha = require_sha(tree.get("sha"), "candidate tree.sha")
    commit = require_object(
        request(
            "POST",
            "/git/commits",
            {
                "message": "feat(ci): declare source-specific enforcement app bindings (#10124)",
                "tree": tree_sha,
                "parents": [BASE_SHA],
            },
        ),
        "candidate commit",
    )
    head_sha = require_sha(commit.get("sha"), "candidate commit.sha")

    encoded_branch = urllib.parse.quote(TARGET_BRANCH, safe="")
    try:
        request("GET", f"/git/ref/heads/{encoded_branch}")
    except SystemExit:
        pass
    else:
        fail(f"target branch already exists: {TARGET_BRANCH}")

    request(
        "POST",
        "/git/refs",
        {"ref": f"refs/heads/{TARGET_BRANCH}", "sha": head_sha},
    )

    receipt = {
        "schema_version": 1,
        "issue": 10124,
        "base_sha": BASE_SHA,
        "branch": TARGET_BRANCH,
        "head_sha": head_sha,
        "paths": list(PRODUCTION_PATHS),
    }
    output = Path("target/10124/result.json")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(json.dumps(receipt, sort_keys=True))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("patch", "verify", "publish"))
    args = parser.parse_args()
    if args.mode == "patch":
        patch()
    elif args.mode == "verify":
        verify()
    else:
        publish()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
